Modo de usar:

Execute os codigos SQL no txt cria_database
Execute Front_CRUD.py
Use seu usuario e senha
be happy!
